#include <conio.h> 
#include <iostream> 
using namespace std; 

int main(){
	char kalimat[]= "ini tes kalimat";
	char *p;
	int kata;
	p = kalimat;
	
	cout<<*p<<"\n";
	cout<<*(p+1)<<"\n";
	cout<<*(p+2)<<"\n";
	cout<<*(p+3)<<"\n";
	
	while(*p!="\0"){
		if(p==" "){
			++kata;
		}
		++p;
	}
	
	cout<<kata<<" jumlah kata";
	
	return 0;
}
#include <iostream>
using namespace std;

main(){
	struct nilai{
		int mtk;
		int ipa;
		int pai;
	};
	
	struct mahasiswa{
		char nama[30];
		char alamat[20];
		int nim;
		struct nilai val;
	};
	
	mahasiswa mhs;

	cout<<"Input Nama	: "; cin>>mhs.nama;
	cout<<"Input Alamat	: "; cin>>mhs.alamat;
	cout<<"Input NIM	: "; cin>>mhs.nim;
	
	cout<<"Nilai MTK	: "; cin>>mhs.val.mtk;
	cout<<"Nilai IPA	: "; cin>>mhs.val.ipa;
	cout<<"Nilai PAI	: "; cin>>mhs.val.pai;
	
	cout<<"\nData Mahasiswa";
	cout<<"\nNama	: "<<mhs.nama;
	cout<<"\nAlamat	: "<<mhs.alamat;
	cout<<"\nNIM	: "<<mhs.nim;
	
	cout<<"\nMTK	: "<<mhs.val.mtk;
	cout<<"\nIPA	: "<<mhs.val.ipa;
	cout<<"\nPAI	: "<<mhs.val.pai;
}
#include <iostream>
#define MAX 5
using namespace std;

struct queue{
	int data[MAX];
	int awal, akhir;
} antrean;

void init(){
	antrean.awal = -1;
	antrean.akhir = -1;
}

void clear(){
	antrean.awal = -1;
	antrean.akhir = -1;
}

bool full(){
	if(antrean.akhir==MAX-1){
		return true;
	}else{
		return false;
	}
}

bool empty(){
	if(antrean.akhir==-1){
		return true;
	}else{
		return false;
	}
}

void tampilData(){
	if(!empty()){
		for(int i=antrean.awal; i<antrean.akhir; i++){
			cout<<antrean.data[i]<<" | ";
		}
	}
	cout<<"\n";
}

void inQueue(){
	tampilData();
	int elemen;
	
	if(!full()){
		cout<<"Data yang akan dimasukkan: "; cin>>elemen;
		antrean.data[antrean.akhir]=elemen;
		antrean.akhir++;
		cout<<"Data berhasil ditambahkan\n";
	}else{
		cout<<"Queue penuh\n";
	}
	getchar();
}

void deQueue(){
	tampilData();
	
	if(!empty()){
		cout<<"\nMengambil data \" "<<antrean.data[antrean.awal]<<" \"...\n";
		for(int i = antrean.awal; i<antrean.akhir; i++){
			antrean.data[i]=antrean.data[i+1];
		}
		antrean.akhir--;
	}else{
		cout<<"Queue kosong\n";
	}
	getchar();
}

main(){
	int pilih, elemen;
	init();
	cout<<"Demo Queue dengan Linear Array\n";
	do{
		tampilData();
		cout<<"\nMenu Utama\n"
			<<"[1] Init\n"
			<<"[2] InQueue\n"
			<<"[3] DeQueue\n"
			<<"[4] Clear\n"
			<<"[0] Keluar\n"
			<<"Input pilihan: ";cin>>pilih;
		switch(pilih){
			case 1: init(); 	break;
			case 2: inQueue(); 	break;
			case 3: deQueue(); 	break;
			case 4: clear(); 	break;
		}
	}while(pilih!=0);
}


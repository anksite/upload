#include <iostream>
#define max 10
using namespace std;

struct tumpukan{
	int atas;
	int data[max];
} T;

void init(){
	T.atas=-1;
}

bool isEmpty(){
	if(T.atas==-1){
		cout<<"stack is empty";
		return true;
	}else{
		return false;
	}
}

bool isFull(){
	if(T.atas==max-1){
		cout<<"stack is full";
		return true;
	}else{
		return false;
	}
}

void input(int data){
	if(!isFull()){
		++T.atas;
		T.data[T.atas]=data;
		cout<<"Data "<<T.data[T.atas]<<" masuk ke stack";
	}
}

void hapus(){
	if(!isEmpty()){
		--T.atas;
		cout<<"Data teratas terhapus";
	}
}

void tampil(){
	if(!isEmpty()){
		for(int i=T.atas; i>=0; i--){
			cout<<"\nTumpukan ke "<<i<<"="<<T.data[i];
		}
	}
}

void clear(){
	T.atas=-1;
	cout<<"stack cleared";
}

main(){
	int pilih, data;
	init();
	
	do{
		cout<<"1. Input\n2. Hapus\n3. Tampil\n4. Clear\n"
			<<"5. Keluar\nMasukkan pilihan: "; cin>>pilih;
		
		switch(pilih){
			case 1:cout<<"Masukkan data = "; cin>>data;
				input(data); 	break;
			case 2: hapus(); 	break;
			case 3: tampil(); 	break;
			case 4: clear(); 	break;
			case 5: cout<<"Terimakasih";
		}
		
		getchar();
		cout<<"\n";
		cout<<"\n";
	}while(pilih!=5);
}
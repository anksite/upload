#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

struct simpul{
	char nama[20];
	float nilai;
	simpul *next;
}data;

main(){
	data *simpul1, *simpul2, simpul3, *temp;
	
	simpul1=(data *)malloc(sizeof(data));
	simpul2=(data *)malloc(sizeof(data));
	
	strcpy(simpul1->nama,"Cantika");
	strcpy(simpul2->nama,"Rahayu");
	
	simpul1->nilai=60;
	simpul2->nilai=80;
	
	simpul1->next = simpul2;
	simpul2->next = simpul3;
	simpul3->next = NULL;
	
	cout<<"Kondisi Awal";
	temp = simpul1;
}
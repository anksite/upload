#include <iostream>
using namespace std;

main(){
	struct mahasiswa{
		int nim[2];
		string nama[2];
		string alamat[2];
		float ipk[2];
	};
	
	mahasiswa mhs;

	for(int i=0; i<2; i++){
		cout<<"Input NIM	: "; cin>>mhs.nim[i];
		cout<<"Input Nama	: "; cin>>mhs.nama[i];
		cout<<"Input Alamat	: "; cin>>mhs.alamat[i];
		cout<<"Input IPK	: "; cin>>mhs.ipk[i];
		cout<<"\n";
	}
	
	for(int i=0; i<2; i++){
		cout<<"\nData Mahasiswa "<<(i+1);
		cout<<"\nNIM	: "<<mhs.nim[i];
		cout<<"\nNama	: "<<mhs.nama[i];
		cout<<"\nAlamat	: "<<mhs.alamat[i];
		cout<<"\nIPK	: "<<mhs.ipk[i];
		cout<<"\n";
	}
	
}
#include <iostream>
#include <conio.h>
using namespace std;

main(){
	struct data{
		int thnMasuk;
		string prodi;
		string nomor;
	};
	
	struct mahasiswa{
		int nim;
		string nama;
		string alamat;
		struct data data;
	};
	
	mahasiswa mhs[2];

	for(int i=0; i<2; i++){
		cout<<"Input NIM			: "; cin>>mhs[i].nim;
		cout<<"Input Nama			: "; cin>>mhs[i].nama;
		cout<<"Input Alamat			: "; cin>>mhs[i].alamat;
		cout<<"Input Tahun Masuk		: "; cin>>mhs[i].data.thnMasuk;
		cout<<"Input Prodi			: "; cin>>mhs[i].data.prodi;
		cout<<"Input Nomor			: "; cin>>mhs[i].data.nomor;
		cout<<"\n";
	}
	
	for(int i=0; i<2; i++){
		cout<<"\nData Mahasiswa "<<(i+1);
		cout<<"\nNIM			: "<<mhs[i].nim;
		cout<<"\nNama			: "<<mhs[i].nama;
		cout<<"\nAlamat			: "<<mhs[i].alamat;
		cout<<"\nTahun Masuk		: "<<mhs[i].data.thnMasuk;
		cout<<"\nProdi			: "<<mhs[i].data.prodi;
		cout<<"\nNomor			: "<<mhs[i].data.nomor;
		cout<<"\n";
	}
	
	getch();
}
#include <iostream>
#include <cstdlib>
#include <string.h>
#define MAX 10
using namespace std;

struct queue{
	char data[10][20];
	int awal, akhir;
} antrean;

void init(){
	antrean.awal = -1;
	antrean.akhir = -1;
}

void clear(){
	antrean.awal = -1;
	antrean.akhir = -1;
	cout<<"Semua data terhapus";
}

bool full(){
	if(antrean.akhir==MAX-1){
		return true;
	}else{
		return false;
	}
}

bool empty(){
	if(antrean.akhir==-1){
		return true;
	}else{
		return false;
	}
}

void tampilData(){
	if(!empty()){
		for(int i=antrean.awal; i<antrean.akhir; i++){
			cout<<"Data ke-"<<i+1<<": "<<antrean.data[i]<<endl;
		}
	}
	cout<<"\n";
}

void inQueue(){
	if(!full()){
		char data[20];
		cout<<"Data :"; cin>>data;
		antrean.awal = 0;
		antrean.akhir++;
		strcpy(antrean.data[antrean.akhir], data);
	}else{
		cout<<"Queue penuh\n";
	}
}

void deQueue(){
	if(!empty()){
		cout<<"Mengambil data "<<antrean.data[antrean.awal]<<" \"...\n";
		for(int i = antrean.awal; i<antrean.akhir; i++){
			strcpy(antrean.data[i], antrean.data[i+1]);
		}
		antrean.akhir--;
	}else{
		cout<<"Queue kosong\n";
	}
}

main(){
	int pilih;
	init();
	cout<<"Demo Queue dengan Linear Array";
	do{
		cout<<"\nMenu Utama\n"
			<<"[1] Input\n"
			<<"[2] Delete\n"
			<<"[3] Print\n"
			<<"[4] Clear\n"
			<<"[5] Keluar\n"
			<<"Input pilihan: ";cin>>pilih;
		switch(pilih){
			case 1: inQueue(); 		break;
			case 2: deQueue(); 		break;
			case 3: tampilData(); 	break;
			case 4: clear(); 		break;
		}
	}while(pilih!=0);
}

